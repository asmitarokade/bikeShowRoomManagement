package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Payment;
import com.example.demo.service.PaymentService;

@RestController
@RequestMapping("/api/v1/payment")
public class PaymentController {
	
	@Autowired
	PaymentService ps;
	
	@PostMapping(value = "/add", consumes = "application/json")
	public ResponseEntity<List> addPayment(@RequestBody Payment c)
	{
		List<Payment> plist=ps.addPayment(c);
		return new ResponseEntity<List>(plist, HttpStatus.CREATED);
	}
	
	@GetMapping(value = "/getAllPayment")
	public List<Payment> getAllPayment()
	{
		List<Payment> plist=ps.getAllPayment();
		return plist;
	}
	
	@PutMapping(value = "/update/{payId}", consumes = "application/json")

    public ResponseEntity<Payment> updatePayment(@PathVariable Integer payId,@RequestBody Payment p)

    {

		Payment plist=ps.updatePayment(payId, p);

        return new ResponseEntity<Payment>(plist,HttpStatus.OK);

    }

    

    @DeleteMapping(value = "/delete/{payId}", consumes = "application/json")

    public ResponseEntity<List<Payment>> deletePayment(@PathVariable Integer payId)

    {

        List<Payment> plist=ps.deletePayment(payId);

        return new ResponseEntity<List<Payment>>(plist, HttpStatus.OK);

    }

    @GetMapping(value = "/getPaymentById/{payId}", consumes = "application/json")
    public ResponseEntity<Payment> getByPaymentId(@PathVariable Integer payId)
    {
    	Payment plist=ps.getPaymentById(payId);
        return new ResponseEntity<Payment>(plist, HttpStatus.OK);
    }
    
    @GetMapping(value = "/getPaymentDetailsBybookId/{bookId}")
    public List<Payment> getPaymentBybookId(@PathVariable Integer bookId)
    {
    	List<Payment> plist=ps.findPaymentBybookId(bookId);
    	return plist;
    }

}
