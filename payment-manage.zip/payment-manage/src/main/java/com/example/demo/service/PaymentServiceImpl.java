package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Payment;
import com.example.demo.repository.PaymentRepository;

@Service
public class PaymentServiceImpl implements PaymentService {

	@Autowired
	PaymentRepository pr;
	
	@Override
	public List<Payment> getAllPayment() {
		// TODO Auto-generated method stub
		return pr.findAll();
	}

	@Override
	public List<Payment> addPayment(Payment c) {
		// TODO Auto-generated method stub
		pr.save(c);
		return pr.findAll();
	}

	@Override
	public Payment updatePayment(Integer payId, Payment c) {
		// TODO Auto-generated method stub
		Optional<Payment> plist=pr.findById(payId);
		Payment p1=plist.get();
		p1.setPayId(c.getPayId());
		p1.setPayType(c.getPayType());
		p1.setPayDate(c.getPayDate());
		pr.save(p1);
		return pr.findById(p1.getPayId()).get();
	}

	@Override
	public List<Payment> deletePayment(Integer payId) {
		// TODO Auto-generated method stub
		pr.deleteById(payId);
		return pr.findAll();
	}

	@Override
	public Payment getPaymentById(Integer payId) {
		// TODO Auto-generated method stub
		Optional<Payment> plist=pr.findById(payId);
		return plist.get();
	}

	@Override
	public List<Payment> findPaymentBybookId(Integer bookId) {
		// TODO Auto-generated method stub
		return pr.findPaymentBybookId(bookId);
	}

}
