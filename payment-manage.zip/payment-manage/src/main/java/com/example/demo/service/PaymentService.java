package com.example.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.entity.Payment;



@Service
public interface PaymentService {
	List<Payment> getAllPayment();
    List<Payment> addPayment(Payment c);
    Payment updatePayment(Integer payId, Payment c);
	List<Payment>deletePayment(Integer payId);
	Payment getPaymentById(Integer payId);
	List<Payment> findPaymentBybookId(Integer bookId);

}
