package com.bsl.demo.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bsl.demo.model.Login;

@Service
public interface LoginService {
List<Login> addLogin(Login e);
Login updateLogin(String username,Login t);
List<Login>deleteLogin(String username);
Login getLoginByUsername(String username);
List<Login> getAllLogin();

}
