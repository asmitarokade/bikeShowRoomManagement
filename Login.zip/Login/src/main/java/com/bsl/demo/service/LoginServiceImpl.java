package com.bsl.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bsl.demo.model.Login;
import com.bsl.demo.repository.LoginRepository;
@Service
public class LoginServiceImpl implements LoginService {

	@Autowired	
    LoginRepository lr;
	@Override
	public List<Login> addLogin(Login e) {
		// TODO Auto-generated method stub
		lr.save(e);
		return lr.findAll();
	}

	@Override
	public Login updateLogin(String username, Login t) {
		// TODO Auto-generated method stub
		Optional<Login> obj=lr.findById(username);
		Login e=obj.get();
		e.setUsername(t.getUsername());
		e.setPassword(t.getPassword());
		lr.save(e);
		return lr.findById(e.getUsername()).get();
	}

	@Override
	public List<Login> deleteLogin(String username) {
		// TODO Auto-generated method stub
		lr.deleteById(username);
		return lr.findAll();
	}

	@Override
	public Login getLoginByUsername(String username) {
		// TODO Auto-generated method stub
		Optional<Login> ob=lr.findById(username);
		return ob.get();
	}

	@Override
	public List<Login> getAllLogin() {
		// TODO Auto-generated method stub
		
		return lr.findAll();
	}

}
